﻿namespace Domain
{
    public class CompanyAdmin : User
    {

    }
}
﻿namespace Domain
{
    public class Administrator : User;
}

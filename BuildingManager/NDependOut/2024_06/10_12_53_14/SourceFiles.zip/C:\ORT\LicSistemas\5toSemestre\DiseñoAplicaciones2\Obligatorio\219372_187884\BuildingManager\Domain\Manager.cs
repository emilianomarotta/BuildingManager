﻿namespace Domain
{
    public class Manager : User;
}

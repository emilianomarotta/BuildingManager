﻿namespace DTOs.In
{
    public class SessionCreateModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}

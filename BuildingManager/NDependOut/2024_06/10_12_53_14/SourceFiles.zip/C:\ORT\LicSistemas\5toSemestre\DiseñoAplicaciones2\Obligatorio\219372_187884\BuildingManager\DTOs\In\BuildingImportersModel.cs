﻿namespace DTOs.In
{
    public class BuildingImportersModel
    {
        public string Nombre { get; set; }
        public AddressModel Direccion { get; set; }
        public string Encargado { get; set; }
        public GpsModel Gps { get; set; }
        public int Gastos_Comunes { get; set; }
        public List<ApartmentImporterModel> Departamentos { get; set; }
    }
}

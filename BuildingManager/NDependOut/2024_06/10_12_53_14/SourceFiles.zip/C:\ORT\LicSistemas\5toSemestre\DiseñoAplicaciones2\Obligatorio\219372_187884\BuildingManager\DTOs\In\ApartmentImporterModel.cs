﻿namespace DTOs.In
{
    public class ApartmentImporterModel
    {
        public int Piso { get; set; }
        public int NumeroPuerta { get; set; }
        public int Habitaciones { get; set; }
        public bool ConTerraza { get; set; }
        public int Baños { get; set; }
        public string PropietarioEmail { get; set; }
    }
}

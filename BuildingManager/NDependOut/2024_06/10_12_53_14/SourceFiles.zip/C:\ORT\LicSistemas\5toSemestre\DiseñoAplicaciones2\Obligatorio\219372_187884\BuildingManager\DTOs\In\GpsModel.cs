﻿namespace DTOs.In
{
    public class GpsModel
    {
        public double Latitud { get; set; }
        public double Longitud { get; set; }
    }
}

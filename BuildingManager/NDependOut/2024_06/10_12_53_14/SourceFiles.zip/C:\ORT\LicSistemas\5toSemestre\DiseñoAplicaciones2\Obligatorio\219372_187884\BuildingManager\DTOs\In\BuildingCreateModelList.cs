﻿using System.Xml.Serialization;

namespace DTOs.In
{
    [XmlRoot("root")]
    public class BuildingCreateModelList
    {
        [XmlElement("edificios")]
        public List<BuildingImportersModel> Buildings { get; set; }
    }
}

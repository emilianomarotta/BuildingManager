﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Task = Domain.Task;

namespace DataAccess
{
    public class SessionRepository : GenericRepository<Session>
    {
        public SessionRepository(DbContext context)
        {
            Context = context;
        }
    }
}


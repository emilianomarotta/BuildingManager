﻿using IImporter;

namespace IImporterLogic
{
    public interface ImporterLogicInterface
    {
        List<ImporterInterface> GetAllImporters();
    }
}

﻿namespace Domain.DataTypes
{
    public enum Role
    {
        Manager,
        CompanyAdmin
    }
}
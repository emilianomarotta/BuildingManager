﻿namespace DTOs.In
{
    public class AddressModel
    {
        public string Calle_Principal { get; set; }
        public int Numero_Puerta { get; set; }
        public string Calle_Secundaria { get; set; }
    }
}

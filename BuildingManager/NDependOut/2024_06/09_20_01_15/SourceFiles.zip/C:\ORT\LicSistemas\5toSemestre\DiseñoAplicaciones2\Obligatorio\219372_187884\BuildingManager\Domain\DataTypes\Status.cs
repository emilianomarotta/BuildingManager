﻿namespace Domain.DataTypes
{
    public enum Status
    {
        Accepted,
        Expired,
        Pending,
        Rejected
    }
}
﻿namespace Domain
{
    public class Staff : User
    {

    }
}
